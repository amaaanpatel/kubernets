from pi import *

print (leibniz_pi(100000000, 20))
