#!/bin/sh

# Delete the container named gcloud
docker rm gcloud
